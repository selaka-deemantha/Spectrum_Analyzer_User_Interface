proc checkRequiredFiles { origin_dir} {
  set status true
  set files [list \
 "[file normalize "$origin_dir/project_1.srcs/sources_1/new/adc_data_gen.v"]"\
 "[file normalize "$origin_dir/project_1.srcs/sources_1/new/adc_interface_fft_vco.v"]"\
 "[file normalize "$origin_dir/project_1.srcs/sources_1/new/vco_interface.v"]"\
 "[file normalize "$origin_dir/project_1.srcs/sources_1/new/AND.v"]"\
 "[file normalize "$origin_dir/project_1.srcs/sources_1/new/window.mem"]"\
 "[file normalize "$origin_dir/project_1.srcs/sim_1/new/tb.v"]"\
  ]
  foreach ifile $files {
    if { ![file isfile $ifile] } {
      puts " Could not find local file $ifile "
      set status false
    }
  }

  return $status
}
# Set the reference directory for source file relative paths (by default the value is script directory path)
set origin_dir "."

# Use origin directory path location variable, if specified in the tcl shell
if { [info exists ::origin_dir_loc] } {
  set origin_dir $::origin_dir_loc
}

# Set the project name
set _xil_proj_name_ "project_1"

# Use project name variable, if specified in the tcl shell
if { [info exists ::user_project_name] } {
  set _xil_proj_name_ $::user_project_name
}

variable script_file
set script_file "build.tcl"

# Help information for this script
proc print_help {} {
  variable script_file
  puts "\nDescription:"
  puts "Recreate a Vivado project from this script. The created project will be"
  puts "functionally equivalent to the original project for which this script was"
  puts "generated. The script contains commands for creating a project, filesets,"
  puts "runs, adding/importing sources and setting properties on various objects.\n"
  puts "Syntax:"
  puts "$script_file"
  puts "$script_file -tclargs \[--origin_dir <path>\]"
  puts "$script_file -tclargs \[--project_name <name>\]"
  puts "$script_file -tclargs \[--help\]\n"
  puts "Usage:"
  puts "Name                   Description"
  puts "-------------------------------------------------------------------------"
  puts "\[--origin_dir <path>\]  Determine source file paths wrt this path. Default"
  puts "                       origin_dir path value is \".\", otherwise, the value"
  puts "                       that was set with the \"-paths_relative_to\" switch"
  puts "                       when this script was generated.\n"
  puts "\[--project_name <name>\] Create project with the specified name. Default"
  puts "                       name is the name of the project from where this"
  puts "                       script was generated.\n"
  puts "\[--help\]               Print help information for this script"
  puts "-------------------------------------------------------------------------\n"
  exit 0
}

if { $::argc > 0 } {
  for {set i 0} {$i < $::argc} {incr i} {
    set option [string trim [lindex $::argv $i]]
    switch -regexp -- $option {
      "--origin_dir"   { incr i; set origin_dir [lindex $::argv $i] }
      "--project_name" { incr i; set _xil_proj_name_ [lindex $::argv $i] }
      "--help"         { print_help }
      default {
        if { [regexp {^-} $option] } {
          puts "ERROR: Unknown option '$option' specified, please type '$script_file -tclargs --help' for usage info.\n"
          return 1
        }
      }
    }
  }
}

# Set the directory path for the original project from where this script was exported
set orig_proj_dir "[file normalize "$origin_dir/"]"

# Check for paths and files needed for project creation
set validate_required 0
if { $validate_required } {
  if { [checkRequiredFiles $origin_dir] } {
    puts "Tcl file $script_file is valid. All files required for project creation is accesable. "
  } else {
    puts "Tcl file $script_file is not valid. Not all files required for project creation is accesable. "
    return
  }
}

# Create project
create_project ${_xil_proj_name_} ./${_xil_proj_name_} -part xc7z020clg484-1

# Set the directory path for the new project
set proj_dir [get_property directory [current_project]]

# Set project properties
set obj [current_project]
set_property -name "board_part_repo_paths" -value "[file normalize "/tools/Vivado_2021_2/Vivado/2021.2/data/boards/board_files"]" -objects $obj
set_property board_part "avnet-tria:zedboard:part0:1.5" $obj
set_property -name "default_lib" -value "xil_defaultlib" -objects $obj
set_property -name "enable_vhdl_2008" -value "1" -objects $obj
set_property -name "ip_cache_permissions" -value "read write" -objects $obj
set_property -name "ip_output_repo" -value "$proj_dir/${_xil_proj_name_}.cache/ip" -objects $obj
set_property -name "mem.enable_memory_map_generation" -value "1" -objects $obj
set_property -name "platform.board_id" -value "zedboard" -objects $obj
set_property -name "revised_directory_structure" -value "1" -objects $obj
set_property -name "sim.central_dir" -value "$proj_dir/${_xil_proj_name_}.ip_user_files" -objects $obj
set_property -name "sim.ip.auto_export_scripts" -value "1" -objects $obj
set_property -name "simulator_language" -value "Mixed" -objects $obj
set_property -name "webtalk.activehdl_export_sim" -value "6" -objects $obj
set_property -name "webtalk.modelsim_export_sim" -value "6" -objects $obj
set_property -name "webtalk.questa_export_sim" -value "6" -objects $obj
set_property -name "webtalk.riviera_export_sim" -value "6" -objects $obj
set_property -name "webtalk.vcs_export_sim" -value "6" -objects $obj
set_property -name "webtalk.xcelium_export_sim" -value "6" -objects $obj
set_property -name "webtalk.xsim_export_sim" -value "6" -objects $obj
set_property -name "webtalk.xsim_launch_sim" -value "5" -objects $obj
set_property -name "xpm_libraries" -value "XPM_MEMORY" -objects $obj

# Create 'sources_1' fileset (if not found)
if {[string equal [get_filesets -quiet sources_1] ""]} {
  create_fileset -srcset sources_1
}

# Set 'sources_1' fileset object
set obj [get_filesets sources_1]
# Import local files from the original project
set files [list \
 [file normalize "${origin_dir}/project_1.srcs/sources_1/new/adc_data_gen.v" ]\
 [file normalize "${origin_dir}/project_1.srcs/sources_1/new/adc_interface_fft_vco.v" ]\
 [file normalize "${origin_dir}/project_1.srcs/sources_1/new/vco_interface.v" ]\
 [file normalize "${origin_dir}/project_1.srcs/sources_1/new/AND.v" ]\
 [file normalize "${origin_dir}/project_1.srcs/sources_1/new/window.mem" ]\
]
set imported_files [import_files -fileset sources_1 $files]

# Set 'sources_1' fileset file properties for remote files
# None

# Set 'sources_1' fileset file properties for local files
set file "new/window.mem"
set file_obj [get_files -of_objects [get_filesets sources_1] [list "*$file"]]
set_property -name "file_type" -value "Memory File" -objects $file_obj


# Set 'sources_1' fileset properties
set obj [get_filesets sources_1]
set_property -name "top" -value "design_1_wrapper" -objects $obj

# Create 'constrs_1' fileset (if not found)
if {[string equal [get_filesets -quiet constrs_1] ""]} {
  create_fileset -constrset constrs_1
}

# Set 'constrs_1' fileset object
set obj [get_filesets constrs_1]

# Empty (no sources present)

# Set 'constrs_1' fileset properties
set obj [get_filesets constrs_1]

# Create 'sim_1' fileset (if not found)
if {[string equal [get_filesets -quiet sim_1] ""]} {
  create_fileset -simset sim_1
}

# Set 'sim_1' fileset object
set obj [get_filesets sim_1]
# Import local files from the original project
set files [list \
 [file normalize "${origin_dir}/project_1.srcs/sim_1/new/tb.v" ]\
]
set imported_files [import_files -fileset sim_1 $files]

# Set 'sim_1' fileset file properties for remote files
# None

# Set 'sim_1' fileset file properties for local files
# None

# Set 'sim_1' fileset properties
set obj [get_filesets sim_1]
set_property -name "top" -value "tb" -objects $obj
set_property -name "top_auto_set" -value "0" -objects $obj
set_property -name "top_lib" -value "xil_defaultlib" -objects $obj

# Set 'utils_1' fileset object
set obj [get_filesets utils_1]
# Empty (no sources present)

# Set 'utils_1' fileset properties
set obj [get_filesets utils_1]


# Adding sources referenced in BDs, if not already added
if { [get_files adc_data_gen.v] == "" } {
  import_files -quiet -fileset sources_1 ./project_1.srcs/sources_1/new/adc_data_gen.v
}
if { [get_files adc_interface_fft_vco.v] == "" } {
  import_files -quiet -fileset sources_1 ./project_1.srcs/sources_1/new/adc_interface_fft_vco.v
}
if { [get_files vco_interface.v] == "" } {
  import_files -quiet -fileset sources_1 ./project_1.srcs/sources_1/new/vco_interface.v
}
if { [get_files AND.v] == "" } {
  import_files -quiet -fileset sources_1 ./project_1.srcs/sources_1/new/AND.v
}
if { [get_files AND.v] == "" } {
  import_files -quiet -fileset sources_1 ./project_1.srcs/sources_1/new/AND.v
}
if { [get_files AND.v] == "" } {
  import_files -quiet -fileset sources_1 ./project_1.srcs/sources_1/new/AND.v
}


# Proc to create BD design_1
proc cr_bd_design_1 { parentCell } {
# The design that will be created by this Tcl proc contains the following 
# module references:
# AND, AND, AND, adc_data_gen, adc_interface_fft_vco, vco_interface



  # CHANGE DESIGN NAME HERE
  set design_name design_1

  common::send_gid_msg -ssname BD::TCL -id 2010 -severity "INFO" "Currently there is no design <$design_name> in project, so creating one..."

  create_bd_design $design_name

  set bCheckIPsPassed 1
  ##################################################################
  # CHECK IPs
  ##################################################################
  set bCheckIPs 1
  if { $bCheckIPs == 1 } {
     set list_check_ips "\ 
  xilinx.com:ip:floating_point:7.1\
  xilinx.com:ip:xfft:9.1\
  xilinx.com:ip:xlconcat:2.1\
  xilinx.com:ip:xlconstant:1.1\
  xilinx.com:ip:xlslice:1.0\
  "

   set list_ips_missing ""
   common::send_gid_msg -ssname BD::TCL -id 2011 -severity "INFO" "Checking if the following IPs exist in the project's IP catalog: $list_check_ips ."

   foreach ip_vlnv $list_check_ips {
      set ip_obj [get_ipdefs -all $ip_vlnv]
      if { $ip_obj eq "" } {
         lappend list_ips_missing $ip_vlnv
      }
   }

   if { $list_ips_missing ne "" } {
      catch {common::send_gid_msg -ssname BD::TCL -id 2012 -severity "ERROR" "The following IPs are not found in the IP Catalog:\n  $list_ips_missing\n\nResolution: Please add the repository containing the IP(s) to the project." }
      set bCheckIPsPassed 0
   }

  }

  ##################################################################
  # CHECK Modules
  ##################################################################
  set bCheckModules 1
  if { $bCheckModules == 1 } {
     set list_check_mods "\ 
  AND\
  AND\
  AND\
  adc_data_gen\
  adc_interface_fft_vco\
  vco_interface\
  "

   set list_mods_missing ""
   common::send_gid_msg -ssname BD::TCL -id 2020 -severity "INFO" "Checking if the following modules exist in the project's sources: $list_check_mods ."

   foreach mod_vlnv $list_check_mods {
      if { [can_resolve_reference $mod_vlnv] == 0 } {
         lappend list_mods_missing $mod_vlnv
      }
   }

   if { $list_mods_missing ne "" } {
      catch {common::send_gid_msg -ssname BD::TCL -id 2021 -severity "ERROR" "The following module(s) are not found in the project: $list_mods_missing" }
      common::send_gid_msg -ssname BD::TCL -id 2022 -severity "INFO" "Please add source files for the missing module(s) above."
      set bCheckIPsPassed 0
   }
}

  if { $bCheckIPsPassed != 1 } {
    common::send_gid_msg -ssname BD::TCL -id 2023 -severity "WARNING" "Will not continue with creation of design due to the error(s) above."
    return 3
  }

  variable script_folder

  if { $parentCell eq "" } {
     set parentCell [get_bd_cells /]
  }

  # Get object for parentCell
  set parentObj [get_bd_cells $parentCell]
  if { $parentObj == "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2090 -severity "ERROR" "Unable to find parent cell <$parentCell>!"}
     return
  }

  # Make sure parentObj is hier blk
  set parentType [get_property TYPE $parentObj]
  if { $parentType ne "hier" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2091 -severity "ERROR" "Parent <$parentObj> has TYPE = <$parentType>. Expected to be <hier>."}
     return
  }

  # Save current instance; Restore later
  set oldCurInst [current_bd_instance .]

  # Set parent object as current
  current_bd_instance $parentObj


  # Create interface ports

  # Create ports
  set Reset [ create_bd_port -dir I -type rst Reset ]
  set_property -dict [ list \
   CONFIG.POLARITY {ACTIVE_HIGH} \
 ] $Reset
  set clk [ create_bd_port -dir I -type clk -freq_hz 100000000 clk ]
  set fft_power_tdata [ create_bd_port -dir O -from 31 -to 0 fft_power_tdata ]
  set fft_power_tlast [ create_bd_port -dir O fft_power_tlast ]
  set fft_power_tvalid [ create_bd_port -dir O fft_power_tvalid ]
  set fft_tdata [ create_bd_port -dir O -from 63 -to 0 fft_tdata ]
  set fft_tlast [ create_bd_port -dir O fft_tlast ]
  set fft_tready [ create_bd_port -dir O fft_tready ]
  set fft_tvalid [ create_bd_port -dir O fft_tvalid ]
  set o_vco_clk_0 [ create_bd_port -dir O -type clk o_vco_clk_0 ]
  set o_vco_data_0 [ create_bd_port -dir O o_vco_data_0 ]
  set o_vco_le_0 [ create_bd_port -dir O o_vco_le_0 ]
  set sample_count_out [ create_bd_port -dir O -from 15 -to 0 sample_count_out ]
  set state_out [ create_bd_port -dir O -from 1 -to 0 state_out ]
  set window_ieee_tdata [ create_bd_port -dir O -from 31 -to 0 window_ieee_tdata ]
  set window_ieee_tlast [ create_bd_port -dir O window_ieee_tlast ]
  set window_ieee_tready [ create_bd_port -dir O window_ieee_tready ]
  set window_ieee_tvalid [ create_bd_port -dir O window_ieee_tvalid ]
  set window_normal_tdata [ create_bd_port -dir O -from 31 -to 0 window_normal_tdata ]
  set window_normal_tlast [ create_bd_port -dir O window_normal_tlast ]
  set window_normal_tready [ create_bd_port -dir O window_normal_tready ]
  set window_normal_tvalid [ create_bd_port -dir O window_normal_tvalid ]

  # Create instance: AND_0, and set properties
  set block_name AND
  set block_cell_name AND_0
  if { [catch {set AND_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $AND_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: AND_1, and set properties
  set block_name AND
  set block_cell_name AND_1
  if { [catch {set AND_1 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $AND_1 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: AND_2, and set properties
  set block_name AND
  set block_cell_name AND_2
  if { [catch {set AND_2 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $AND_2 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: adc_data_gen_0, and set properties
  set block_name adc_data_gen
  set block_cell_name adc_data_gen_0
  if { [catch {set adc_data_gen_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $adc_data_gen_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: adc_interface_fft_vco_0, and set properties
  set block_name adc_interface_fft_vco
  set block_cell_name adc_interface_fft_vco_0
  if { [catch {set adc_interface_fft_vco_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $adc_interface_fft_vco_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: floating_point_0, and set properties
  set floating_point_0 [ create_bd_cell -type ip -vlnv xilinx.com:ip:floating_point:7.1 floating_point_0 ]
  set_property -dict [ list \
   CONFIG.C_Accum_Input_Msb {32} \
   CONFIG.C_Accum_Lsb {-31} \
   CONFIG.C_Accum_Msb {32} \
   CONFIG.C_Latency {7} \
   CONFIG.C_Mult_Usage {No_Usage} \
   CONFIG.C_Rate {1} \
   CONFIG.C_Result_Exponent_Width {8} \
   CONFIG.C_Result_Fraction_Width {24} \
   CONFIG.Has_A_TLAST {true} \
   CONFIG.Operation_Type {Fixed_to_float} \
   CONFIG.RESULT_TLAST_Behv {Pass_A_TLAST} \
   CONFIG.Result_Precision_Type {Single} \
 ] $floating_point_0

  # Create instance: floating_point_1, and set properties
  set floating_point_1 [ create_bd_cell -type ip -vlnv xilinx.com:ip:floating_point:7.1 floating_point_1 ]
  set_property -dict [ list \
   CONFIG.C_Latency {9} \
   CONFIG.C_Mult_Usage {Full_Usage} \
   CONFIG.C_Rate {1} \
   CONFIG.C_Result_Exponent_Width {8} \
   CONFIG.C_Result_Fraction_Width {24} \
   CONFIG.Has_A_TLAST {true} \
   CONFIG.Operation_Type {Multiply} \
   CONFIG.RESULT_TLAST_Behv {Pass_A_TLAST} \
   CONFIG.Result_Precision_Type {Single} \
 ] $floating_point_1

  # Create instance: floating_point_2, and set properties
  set floating_point_2 [ create_bd_cell -type ip -vlnv xilinx.com:ip:floating_point:7.1 floating_point_2 ]
  set_property -dict [ list \
   CONFIG.C_Latency {9} \
   CONFIG.C_Mult_Usage {Full_Usage} \
   CONFIG.C_Rate {1} \
   CONFIG.C_Result_Exponent_Width {8} \
   CONFIG.C_Result_Fraction_Width {24} \
   CONFIG.Has_A_TLAST {true} \
   CONFIG.Operation_Type {Multiply} \
   CONFIG.RESULT_TLAST_Behv {Pass_A_TLAST} \
   CONFIG.Result_Precision_Type {Single} \
 ] $floating_point_2

  # Create instance: floating_point_3, and set properties
  set floating_point_3 [ create_bd_cell -type ip -vlnv xilinx.com:ip:floating_point:7.1 floating_point_3 ]
  set_property -dict [ list \
   CONFIG.Add_Sub_Value {Add} \
   CONFIG.Has_A_TLAST {true} \
   CONFIG.Has_B_TLAST {true} \
   CONFIG.RESULT_TLAST_Behv {AND_all_TLASTs} \
 ] $floating_point_3

  # Create instance: vco_interface_0, and set properties
  set block_name vco_interface
  set block_cell_name vco_interface_0
  if { [catch {set vco_interface_0 [create_bd_cell -type module -reference $block_name $block_cell_name] } errmsg] } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2095 -severity "ERROR" "Unable to add referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   } elseif { $vco_interface_0 eq "" } {
     catch {common::send_gid_msg -ssname BD::TCL -id 2096 -severity "ERROR" "Unable to referenced block <$block_name>. Please add the files for ${block_name}'s definition into the project."}
     return 1
   }
  
  # Create instance: xfft_0, and set properties
  set xfft_0 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xfft:9.1 xfft_0 ]
  set_property -dict [ list \
   CONFIG.data_format {floating_point} \
   CONFIG.number_of_stages_using_block_ram_for_data_and_phase_factors {3} \
   CONFIG.output_ordering {natural_order} \
   CONFIG.phase_factor_width {24} \
   CONFIG.target_clock_frequency {100} \
   CONFIG.target_data_throughput {100} \
 ] $xfft_0

  # Create instance: xlconcat_0, and set properties
  set xlconcat_0 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlconcat:2.1 xlconcat_0 ]
  set_property -dict [ list \
   CONFIG.IN0_WIDTH {32} \
   CONFIG.IN1_WIDTH {32} \
 ] $xlconcat_0

  # Create instance: xlconstant_0, and set properties
  set xlconstant_0 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 xlconstant_0 ]
  set_property -dict [ list \
   CONFIG.CONST_VAL {0} \
   CONFIG.CONST_WIDTH {32} \
 ] $xlconstant_0

  # Create instance: xlconstant_1, and set properties
  set xlconstant_1 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 xlconstant_1 ]
  set_property -dict [ list \
   CONFIG.CONST_WIDTH {16} \
 ] $xlconstant_1

  # Create instance: xlconstant_2, and set properties
  set xlconstant_2 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 xlconstant_2 ]

  # Create instance: xlconstant_3, and set properties
  set xlconstant_3 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 xlconstant_3 ]

  # Create instance: xlslice_0, and set properties
  set xlslice_0 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 xlslice_0 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {63} \
   CONFIG.DIN_TO {32} \
   CONFIG.DIN_WIDTH {64} \
   CONFIG.DOUT_WIDTH {32} \
 ] $xlslice_0

  # Create instance: xlslice_1, and set properties
  set xlslice_1 [ create_bd_cell -type ip -vlnv xilinx.com:ip:xlslice:1.0 xlslice_1 ]
  set_property -dict [ list \
   CONFIG.DIN_FROM {31} \
   CONFIG.DIN_WIDTH {64} \
   CONFIG.DOUT_WIDTH {32} \
 ] $xlslice_1

  # Create interface connections
  connect_bd_intf_net -intf_net floating_point_1_M_AXIS_RESULT [get_bd_intf_pins floating_point_1/M_AXIS_RESULT] [get_bd_intf_pins floating_point_3/S_AXIS_A]
  connect_bd_intf_net -intf_net floating_point_2_M_AXIS_RESULT [get_bd_intf_pins floating_point_2/M_AXIS_RESULT] [get_bd_intf_pins floating_point_3/S_AXIS_B]

  # Create port connections
  connect_bd_net -net AND_0_tready_out [get_bd_pins AND_0/tready_out] [get_bd_pins AND_2/tready_2]
  connect_bd_net -net AND_1_tready_out [get_bd_pins AND_1/tready_out] [get_bd_pins AND_2/tready_1]
  connect_bd_net -net AND_2_tready_out [get_bd_ports fft_tready] [get_bd_pins AND_2/tready_out] [get_bd_pins xfft_0/m_axis_data_tready]
  connect_bd_net -net Reset_1 [get_bd_ports Reset] [get_bd_pins adc_interface_fft_vco_0/i_adc_reset] [get_bd_pins vco_interface_0/reset]
  connect_bd_net -net adc_data_gen_0_o_adc_data [get_bd_pins adc_data_gen_0/o_adc_data] [get_bd_pins adc_interface_fft_vco_0/i_adc_data]
  connect_bd_net -net adc_interface_fft_vco_0_m_axis_tdata [get_bd_ports window_normal_tdata] [get_bd_pins adc_interface_fft_vco_0/m_axis_tdata] [get_bd_pins floating_point_0/s_axis_a_tdata]
  connect_bd_net -net adc_interface_fft_vco_0_m_axis_tlast [get_bd_ports window_normal_tlast] [get_bd_pins adc_interface_fft_vco_0/m_axis_tlast] [get_bd_pins floating_point_0/s_axis_a_tlast]
  connect_bd_net -net adc_interface_fft_vco_0_m_axis_tvalid [get_bd_ports window_normal_tvalid] [get_bd_pins adc_interface_fft_vco_0/m_axis_tvalid] [get_bd_pins floating_point_0/s_axis_a_tvalid]
  connect_bd_net -net adc_interface_fft_vco_0_o_adc_vco_req_next_freq [get_bd_pins adc_interface_fft_vco_0/o_adc_vco_req_next_freq] [get_bd_pins vco_interface_0/i_next_freq_req]
  connect_bd_net -net adc_interface_fft_vco_0_sample_count_out [get_bd_ports sample_count_out] [get_bd_pins adc_interface_fft_vco_0/sample_count_out]
  connect_bd_net -net adc_interface_fft_vco_0_state_out [get_bd_ports state_out] [get_bd_pins adc_interface_fft_vco_0/state_out]
  connect_bd_net -net clk_1 [get_bd_ports clk] [get_bd_pins adc_data_gen_0/i_adc_clk] [get_bd_pins adc_interface_fft_vco_0/i_adc_dco] [get_bd_pins floating_point_0/aclk] [get_bd_pins floating_point_1/aclk] [get_bd_pins floating_point_2/aclk] [get_bd_pins floating_point_3/aclk] [get_bd_pins vco_interface_0/i_vco_clk] [get_bd_pins xfft_0/aclk]
  connect_bd_net -net floating_point_0_m_axis_result_tdata [get_bd_ports window_ieee_tdata] [get_bd_pins floating_point_0/m_axis_result_tdata] [get_bd_pins xlconcat_0/In0]
  connect_bd_net -net floating_point_0_m_axis_result_tlast [get_bd_ports window_ieee_tlast] [get_bd_pins floating_point_0/m_axis_result_tlast] [get_bd_pins xfft_0/s_axis_data_tlast]
  connect_bd_net -net floating_point_0_m_axis_result_tvalid [get_bd_ports window_ieee_tvalid] [get_bd_pins floating_point_0/m_axis_result_tvalid] [get_bd_pins xfft_0/s_axis_data_tvalid]
  connect_bd_net -net floating_point_0_s_axis_a_tready [get_bd_ports window_normal_tready] [get_bd_pins adc_interface_fft_vco_0/m_axis_tready] [get_bd_pins floating_point_0/s_axis_a_tready]
  connect_bd_net -net floating_point_1_s_axis_a_tready [get_bd_pins AND_0/tready_2] [get_bd_pins floating_point_1/s_axis_a_tready]
  connect_bd_net -net floating_point_1_s_axis_b_tready [get_bd_pins AND_0/tready_1] [get_bd_pins floating_point_1/s_axis_b_tready]
  connect_bd_net -net floating_point_2_s_axis_a_tready [get_bd_pins AND_1/tready_2] [get_bd_pins floating_point_2/s_axis_a_tready]
  connect_bd_net -net floating_point_2_s_axis_b_tready [get_bd_pins AND_1/tready_1] [get_bd_pins floating_point_2/s_axis_b_tready]
  connect_bd_net -net floating_point_3_m_axis_result_tdata [get_bd_ports fft_power_tdata] [get_bd_pins floating_point_3/m_axis_result_tdata]
  connect_bd_net -net floating_point_3_m_axis_result_tlast [get_bd_ports fft_power_tlast] [get_bd_pins floating_point_3/m_axis_result_tlast]
  connect_bd_net -net floating_point_3_m_axis_result_tvalid [get_bd_ports fft_power_tvalid] [get_bd_pins floating_point_3/m_axis_result_tvalid]
  connect_bd_net -net vco_interface_0_o_vco_clk [get_bd_ports o_vco_clk_0] [get_bd_pins vco_interface_0/o_vco_clk]
  connect_bd_net -net vco_interface_0_o_vco_data [get_bd_ports o_vco_data_0] [get_bd_pins vco_interface_0/o_vco_data]
  connect_bd_net -net vco_interface_0_o_vco_freq [get_bd_pins adc_interface_fft_vco_0/i_adc_vco_prog_freq] [get_bd_pins vco_interface_0/o_vco_freq]
  connect_bd_net -net vco_interface_0_o_vco_le [get_bd_ports o_vco_le_0] [get_bd_pins vco_interface_0/o_vco_le]
  connect_bd_net -net vco_interface_0_o_vco_prog_done [get_bd_pins adc_interface_fft_vco_0/i_adc_vco_prog_done] [get_bd_pins vco_interface_0/o_vco_prog_done]
  connect_bd_net -net xfft_0_m_axis_data_tdata [get_bd_ports fft_tdata] [get_bd_pins xfft_0/m_axis_data_tdata] [get_bd_pins xlslice_0/Din] [get_bd_pins xlslice_1/Din]
  connect_bd_net -net xfft_0_m_axis_data_tlast [get_bd_ports fft_tlast] [get_bd_pins floating_point_1/s_axis_a_tlast] [get_bd_pins floating_point_2/s_axis_a_tlast] [get_bd_pins xfft_0/m_axis_data_tlast]
  connect_bd_net -net xfft_0_m_axis_data_tvalid [get_bd_ports fft_tvalid] [get_bd_pins floating_point_1/s_axis_a_tvalid] [get_bd_pins floating_point_1/s_axis_b_tvalid] [get_bd_pins floating_point_2/s_axis_a_tvalid] [get_bd_pins floating_point_2/s_axis_b_tvalid] [get_bd_pins xfft_0/m_axis_data_tvalid]
  connect_bd_net -net xfft_0_s_axis_data_tready [get_bd_ports window_ieee_tready] [get_bd_pins floating_point_0/m_axis_result_tready] [get_bd_pins xfft_0/s_axis_data_tready]
  connect_bd_net -net xlconcat_0_dout [get_bd_pins xfft_0/s_axis_data_tdata] [get_bd_pins xlconcat_0/dout]
  connect_bd_net -net xlconstant_0_dout [get_bd_pins xlconcat_0/In1] [get_bd_pins xlconstant_0/dout]
  connect_bd_net -net xlconstant_1_dout [get_bd_pins xfft_0/s_axis_config_tdata] [get_bd_pins xlconstant_1/dout]
  connect_bd_net -net xlconstant_2_dout [get_bd_pins vco_interface_0/i_vco_start] [get_bd_pins xfft_0/s_axis_config_tvalid] [get_bd_pins xlconstant_2/dout]
  connect_bd_net -net xlconstant_3_dout [get_bd_pins floating_point_3/m_axis_result_tready] [get_bd_pins xlconstant_3/dout]
  connect_bd_net -net xlslice_0_Dout [get_bd_pins floating_point_2/s_axis_a_tdata] [get_bd_pins floating_point_2/s_axis_b_tdata] [get_bd_pins xlslice_0/Dout]
  connect_bd_net -net xlslice_1_Dout [get_bd_pins floating_point_1/s_axis_a_tdata] [get_bd_pins floating_point_1/s_axis_b_tdata] [get_bd_pins xlslice_1/Dout]

  # Create address segments

  # Perform GUI Layout
  regenerate_bd_layout -layout_string {
   "ActiveEmotionalView":"Default View",
   "Default View_ScaleFactor":"0.26865",
   "Default View_TopLeft":"316,-465",
   "ExpandedHierarchyInLayout":"",
   "guistr":"# # String gsaved with Nlview 7.0r4  2019-12-20 bk=1.5203 VDI=41 GEI=36 GUI=JA:10.0 TLS
#  -string -flagsOSRD
preplace port port-id_clk -pg 1 -lvl 0 -x -40 -y 80 -defaultsOSRD
preplace port port-id_Reset -pg 1 -lvl 0 -x -40 -y 30 -defaultsOSRD
preplace port port-id_o_vco_le_0 -pg 1 -lvl 10 -x 3950 -y 60 -defaultsOSRD
preplace port port-id_o_vco_clk_0 -pg 1 -lvl 10 -x 3950 -y 80 -defaultsOSRD
preplace port port-id_o_vco_data_0 -pg 1 -lvl 10 -x 3950 -y 100 -defaultsOSRD
preplace port port-id_window_normal_tlast -pg 1 -lvl 10 -x 3950 -y -50 -defaultsOSRD
preplace port port-id_window_normal_tvalid -pg 1 -lvl 10 -x 3950 -y -120 -defaultsOSRD
preplace port port-id_window_normal_tready -pg 1 -lvl 10 -x 3950 -y -70 -defaultsOSRD
preplace port port-id_fft_power_tlast -pg 1 -lvl 10 -x 3950 -y 610 -defaultsOSRD
preplace port port-id_fft_power_tvalid -pg 1 -lvl 10 -x 3950 -y 650 -defaultsOSRD
preplace port port-id_window_ieee_tlast -pg 1 -lvl 10 -x 3950 -y 820 -defaultsOSRD
preplace port port-id_window_ieee_tready -pg 1 -lvl 10 -x 3950 -y 840 -defaultsOSRD
preplace port port-id_window_ieee_tvalid -pg 1 -lvl 10 -x 3950 -y 860 -defaultsOSRD
preplace port port-id_fft_tlast -pg 1 -lvl 10 -x 3950 -y 410 -defaultsOSRD
preplace port port-id_fft_tready -pg 1 -lvl 10 -x 3950 -y 530 -defaultsOSRD
preplace port port-id_fft_tvalid -pg 1 -lvl 10 -x 3950 -y 460 -defaultsOSRD
preplace portBus state_out -pg 1 -lvl 10 -x 3950 -y 170 -defaultsOSRD
preplace portBus window_normal_tdata -pg 1 -lvl 10 -x 3950 -y -90 -defaultsOSRD
preplace portBus fft_power_tdata -pg 1 -lvl 10 -x 3950 -y 630 -defaultsOSRD
preplace portBus window_ieee_tdata -pg 1 -lvl 10 -x 3950 -y 370 -defaultsOSRD
preplace portBus fft_tdata -pg 1 -lvl 10 -x 3950 -y 390 -defaultsOSRD
preplace portBus sample_count_out -pg 1 -lvl 10 -x 3950 -y 500 -defaultsOSRD
preplace inst adc_data_gen_0 -pg 1 -lvl 1 -x 360 -y 140 -defaultsOSRD
preplace inst vco_interface_0 -pg 1 -lvl 7 -x 2800 -y 50 -defaultsOSRD
preplace inst xfft_0 -pg 1 -lvl 6 -x 2330 -y 500 -defaultsOSRD
preplace inst floating_point_0 -pg 1 -lvl 3 -x 1290 -y 410 -defaultsOSRD
preplace inst xlconcat_0 -pg 1 -lvl 5 -x 1930 -y 360 -defaultsOSRD
preplace inst xlconstant_0 -pg 1 -lvl 4 -x 1670 -y 410 -defaultsOSRD
preplace inst xlconstant_1 -pg 1 -lvl 5 -x 1930 -y 590 -defaultsOSRD
preplace inst xlconstant_2 -pg 1 -lvl 5 -x 1930 -y 690 -defaultsOSRD
preplace inst floating_point_1 -pg 1 -lvl 8 -x 3290 -y 610 -defaultsOSRD
preplace inst floating_point_2 -pg 1 -lvl 8 -x 3290 -y 990 -defaultsOSRD
preplace inst xlslice_0 -pg 1 -lvl 7 -x 2800 -y 320 -defaultsOSRD
preplace inst xlslice_1 -pg 1 -lvl 7 -x 2800 -y 220 -defaultsOSRD
preplace inst AND_0 -pg 1 -lvl 7 -x 2800 -y 460 -defaultsOSRD -orient R180
preplace inst AND_1 -pg 1 -lvl 7 -x 2800 -y 700 -defaultsOSRD -orient R180
preplace inst AND_2 -pg 1 -lvl 7 -x 2800 -y 580 -defaultsOSRD -orient R180
preplace inst floating_point_3 -pg 1 -lvl 9 -x 3690 -y 610 -defaultsOSRD
preplace inst xlconstant_3 -pg 1 -lvl 9 -x 3690 -y 760 -defaultsOSRD
preplace inst adc_interface_fft_vco_0 -pg 1 -lvl 2 -x 780 -y 420 -defaultsOSRD
preplace netloc adc_data_gen_0_o_adc_data 1 1 1 510J 140n
preplace netloc clk_1 1 0 9 -20 280 530 280 1020 530 N 530 N 530 2050 660 2580 810 3040 760 3500
preplace netloc Reset_1 1 0 7 NJ 30 520 60 N 60 N 60 N 60 N 60 N
preplace netloc adc_interface_fft_vco_0_o_adc_vco_req_next_freq 1 2 5 1010 80 N 80 N 80 N 80 N
preplace netloc vco_interface_0_o_vco_prog_done 1 1 7 550 -60 NJ -60 N -60 N -60 N -60 N -60 2980
preplace netloc vco_interface_0_o_vco_freq 1 1 7 540 -70 NJ -70 N -70 N -70 N -70 N -70 3010
preplace netloc vco_interface_0_o_vco_le 1 7 3 N 10 N 10 3920
preplace netloc vco_interface_0_o_vco_clk 1 7 3 N 30 N 30 3900
preplace netloc vco_interface_0_o_vco_data 1 7 3 N 50 N 50 3890
preplace netloc adc_interface_fft_vco_0_state_out 1 2 8 1030J -110 NJ -110 N -110 N -110 N -110 N -110 N -110 3910
preplace netloc xlconstant_0_dout 1 4 1 1780 370n
preplace netloc xlconcat_0_dout 1 5 1 2100 360n
preplace netloc xlconstant_1_dout 1 5 1 2100 530n
preplace netloc xlconstant_2_dout 1 5 2 2080 40 N
preplace netloc xlslice_1_Dout 1 7 1 3050 220n
preplace netloc xlslice_0_Dout 1 7 1 3010 320n
preplace netloc floating_point_1_s_axis_a_tready 1 7 1 3040 450n
preplace netloc floating_point_1_s_axis_b_tready 1 7 1 2990 470n
preplace netloc floating_point_2_s_axis_a_tready 1 7 1 3000 690n
preplace netloc floating_point_2_s_axis_b_tready 1 7 1 2990 710n
preplace netloc AND_0_tready_out 1 6 2 2590 770 2980
preplace netloc AND_1_tready_out 1 6 2 2600 800 2970
preplace netloc adc_interface_fft_vco_0_m_axis_tdata 1 2 8 1070J -90 NJ -90 NJ -90 NJ -90 NJ -90 NJ -90 NJ -90 NJ
preplace netloc adc_interface_fft_vco_0_m_axis_tlast 1 2 8 1060J -50 NJ -50 NJ -50 NJ -50 NJ -50 NJ -50 NJ -50 NJ
preplace netloc adc_interface_fft_vco_0_m_axis_tvalid 1 2 8 1050J -120 NJ -120 NJ -120 NJ -120 NJ -120 NJ -120 NJ -120 NJ
preplace netloc floating_point_0_s_axis_a_tready 1 2 8 1040 -100 NJ -100 NJ -100 NJ -100 NJ -100 3050J -70 NJ -70 NJ
preplace netloc xlconstant_3_dout 1 9 1 3860 630n
preplace netloc floating_point_3_m_axis_result_tdata 1 9 1 3870 590n
preplace netloc floating_point_3_m_axis_result_tlast 1 9 1 N 610
preplace netloc floating_point_3_m_axis_result_tvalid 1 9 1 N 650
preplace netloc floating_point_0_m_axis_result_tdata 1 3 7 1500J 320 1800J 290 NJ 290 2600J 380 2980J 370 NJ 370 NJ
preplace netloc floating_point_0_m_axis_result_tlast 1 3 7 1510J 330 1790J 430 2090J -80 NJ -80 NJ -80 NJ -80 3880J
preplace netloc xfft_0_s_axis_data_tready 1 3 7 1530 350 1760 450 2040 840 NJ 840 NJ 840 NJ 840 NJ
preplace netloc floating_point_0_m_axis_result_tvalid 1 3 7 1520J 340 1770J 440 2070J 820 NJ 820 NJ 820 NJ 820 3860J
preplace netloc xfft_0_m_axis_data_tdata 1 6 4 2560J 160 NJ 160 NJ 160 3860J
preplace netloc xfft_0_m_axis_data_tlast 1 6 4 2600J 390 3020J 410 NJ 410 NJ
preplace netloc AND_2_tready_out 1 6 4 2570 780 NJ 780 3490J 510 3860J
preplace netloc xfft_0_m_axis_data_tvalid 1 6 4 2560J 830 3030J 460 NJ 460 NJ
preplace netloc adc_interface_fft_vco_0_sample_count_out 1 2 8 1010J 520 NJ 520 NJ 520 2060J 790 NJ 790 NJ 790 3480J 500 NJ
preplace netloc floating_point_1_M_AXIS_RESULT 1 8 1 3470 590n
preplace netloc floating_point_2_M_AXIS_RESULT 1 8 1 3510 610n
levelinfo -pg 1 -40 360 780 1290 1670 1930 2330 2800 3290 3690 3950
pagesize -pg 1 -db -bbox -sgen -130 -230 4200 1140
"
}

  # Restore current instance
  current_bd_instance $oldCurInst

  validate_bd_design
  save_bd_design
  close_bd_design $design_name 
}
# End of cr_bd_design_1()
cr_bd_design_1 ""
set_property REGISTERED_WITH_MANAGER "1" [get_files design_1.bd ] 
set_property SYNTH_CHECKPOINT_MODE "Hierarchical" [get_files design_1.bd ] 

#call make_wrapper to create wrapper files
if { [get_property IS_LOCKED [ get_files -norecurse design_1.bd] ] == 1  } {
  import_files -fileset sources_1 [file normalize "${origin_dir}/project_1.gen/sources_1/bd/design_1/hdl/design_1_wrapper.v" ]
} else {
  set wrapper_path [make_wrapper -fileset sources_1 -files [ get_files -norecurse design_1.bd] -top]
  add_files -norecurse -fileset sources_1 $wrapper_path
}


set idrFlowPropertiesConstraints ""
catch {
 set idrFlowPropertiesConstraints [get_param runs.disableIDRFlowPropertyConstraints]
 set_param runs.disableIDRFlowPropertyConstraints 1
}

# Create 'synth_1' run (if not found)
if {[string equal [get_runs -quiet synth_1] ""]} {
    create_run -name synth_1 -part xc7z020clg484-1 -flow {Vivado Synthesis 2021} -strategy "Vivado Synthesis Defaults" -report_strategy {No Reports} -constrset constrs_1
} else {
  set_property strategy "Vivado Synthesis Defaults" [get_runs synth_1]
  set_property flow "Vivado Synthesis 2021" [get_runs synth_1]
}
set obj [get_runs synth_1]
set_property set_report_strategy_name 1 $obj
set_property report_strategy {Vivado Synthesis Default Reports} $obj
set_property set_report_strategy_name 0 $obj
# Create 'synth_1_synth_report_utilization_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs synth_1] synth_1_synth_report_utilization_0] "" ] } {
  create_report_config -report_name synth_1_synth_report_utilization_0 -report_type report_utilization:1.0 -steps synth_design -runs synth_1
}
set obj [get_report_configs -of_objects [get_runs synth_1] synth_1_synth_report_utilization_0]
if { $obj != "" } {

}
set obj [get_runs synth_1]
set_property -name "auto_incremental_checkpoint" -value "1" -objects $obj
set_property -name "strategy" -value "Vivado Synthesis Defaults" -objects $obj

# set the current synth run
current_run -synthesis [get_runs synth_1]

# Create 'impl_1' run (if not found)
if {[string equal [get_runs -quiet impl_1] ""]} {
    create_run -name impl_1 -part xc7z020clg484-1 -flow {Vivado Implementation 2021} -strategy "Vivado Implementation Defaults" -report_strategy {No Reports} -constrset constrs_1 -parent_run synth_1
} else {
  set_property strategy "Vivado Implementation Defaults" [get_runs impl_1]
  set_property flow "Vivado Implementation 2021" [get_runs impl_1]
}
set obj [get_runs impl_1]
set_property set_report_strategy_name 1 $obj
set_property report_strategy {Vivado Implementation Default Reports} $obj
set_property set_report_strategy_name 0 $obj
# Create 'impl_1_init_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_init_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_init_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps init_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_init_report_timing_summary_0]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj

}
# Create 'impl_1_opt_report_drc_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_opt_report_drc_0] "" ] } {
  create_report_config -report_name impl_1_opt_report_drc_0 -report_type report_drc:1.0 -steps opt_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_opt_report_drc_0]
if { $obj != "" } {

}
# Create 'impl_1_opt_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_opt_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_opt_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps opt_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_opt_report_timing_summary_0]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj

}
# Create 'impl_1_power_opt_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_power_opt_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_power_opt_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps power_opt_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_power_opt_report_timing_summary_0]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj

}
# Create 'impl_1_place_report_io_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_io_0] "" ] } {
  create_report_config -report_name impl_1_place_report_io_0 -report_type report_io:1.0 -steps place_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_io_0]
if { $obj != "" } {

}
# Create 'impl_1_place_report_utilization_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_utilization_0] "" ] } {
  create_report_config -report_name impl_1_place_report_utilization_0 -report_type report_utilization:1.0 -steps place_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_utilization_0]
if { $obj != "" } {

}
# Create 'impl_1_place_report_control_sets_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_control_sets_0] "" ] } {
  create_report_config -report_name impl_1_place_report_control_sets_0 -report_type report_control_sets:1.0 -steps place_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_control_sets_0]
if { $obj != "" } {
set_property -name "options.verbose" -value "1" -objects $obj

}
# Create 'impl_1_place_report_incremental_reuse_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_incremental_reuse_0] "" ] } {
  create_report_config -report_name impl_1_place_report_incremental_reuse_0 -report_type report_incremental_reuse:1.0 -steps place_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_incremental_reuse_0]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj

}
# Create 'impl_1_place_report_incremental_reuse_1' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_incremental_reuse_1] "" ] } {
  create_report_config -report_name impl_1_place_report_incremental_reuse_1 -report_type report_incremental_reuse:1.0 -steps place_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_incremental_reuse_1]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj

}
# Create 'impl_1_place_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_place_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps place_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_place_report_timing_summary_0]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj

}
# Create 'impl_1_post_place_power_opt_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_post_place_power_opt_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_post_place_power_opt_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps post_place_power_opt_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_post_place_power_opt_report_timing_summary_0]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj

}
# Create 'impl_1_phys_opt_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_phys_opt_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_phys_opt_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps phys_opt_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_phys_opt_report_timing_summary_0]
if { $obj != "" } {
set_property -name "is_enabled" -value "0" -objects $obj
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj

}
# Create 'impl_1_route_report_drc_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_drc_0] "" ] } {
  create_report_config -report_name impl_1_route_report_drc_0 -report_type report_drc:1.0 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_drc_0]
if { $obj != "" } {

}
# Create 'impl_1_route_report_methodology_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_methodology_0] "" ] } {
  create_report_config -report_name impl_1_route_report_methodology_0 -report_type report_methodology:1.0 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_methodology_0]
if { $obj != "" } {

}
# Create 'impl_1_route_report_power_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_power_0] "" ] } {
  create_report_config -report_name impl_1_route_report_power_0 -report_type report_power:1.0 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_power_0]
if { $obj != "" } {

}
# Create 'impl_1_route_report_route_status_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_route_status_0] "" ] } {
  create_report_config -report_name impl_1_route_report_route_status_0 -report_type report_route_status:1.0 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_route_status_0]
if { $obj != "" } {

}
# Create 'impl_1_route_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_route_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_timing_summary_0]
if { $obj != "" } {
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj

}
# Create 'impl_1_route_report_incremental_reuse_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_incremental_reuse_0] "" ] } {
  create_report_config -report_name impl_1_route_report_incremental_reuse_0 -report_type report_incremental_reuse:1.0 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_incremental_reuse_0]
if { $obj != "" } {

}
# Create 'impl_1_route_report_clock_utilization_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_clock_utilization_0] "" ] } {
  create_report_config -report_name impl_1_route_report_clock_utilization_0 -report_type report_clock_utilization:1.0 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_clock_utilization_0]
if { $obj != "" } {

}
# Create 'impl_1_route_report_bus_skew_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_bus_skew_0] "" ] } {
  create_report_config -report_name impl_1_route_report_bus_skew_0 -report_type report_bus_skew:1.1 -steps route_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_route_report_bus_skew_0]
if { $obj != "" } {
set_property -name "options.warn_on_violation" -value "1" -objects $obj

}
# Create 'impl_1_post_route_phys_opt_report_timing_summary_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_post_route_phys_opt_report_timing_summary_0] "" ] } {
  create_report_config -report_name impl_1_post_route_phys_opt_report_timing_summary_0 -report_type report_timing_summary:1.0 -steps post_route_phys_opt_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_post_route_phys_opt_report_timing_summary_0]
if { $obj != "" } {
set_property -name "options.max_paths" -value "10" -objects $obj
set_property -name "options.report_unconstrained" -value "1" -objects $obj
set_property -name "options.warn_on_violation" -value "1" -objects $obj

}
# Create 'impl_1_post_route_phys_opt_report_bus_skew_0' report (if not found)
if { [ string equal [get_report_configs -of_objects [get_runs impl_1] impl_1_post_route_phys_opt_report_bus_skew_0] "" ] } {
  create_report_config -report_name impl_1_post_route_phys_opt_report_bus_skew_0 -report_type report_bus_skew:1.1 -steps post_route_phys_opt_design -runs impl_1
}
set obj [get_report_configs -of_objects [get_runs impl_1] impl_1_post_route_phys_opt_report_bus_skew_0]
if { $obj != "" } {
set_property -name "options.warn_on_violation" -value "1" -objects $obj

}
set obj [get_runs impl_1]
set_property -name "strategy" -value "Vivado Implementation Defaults" -objects $obj
set_property -name "steps.write_bitstream.args.readback_file" -value "0" -objects $obj
set_property -name "steps.write_bitstream.args.verbose" -value "0" -objects $obj

# set the current impl run
current_run -implementation [get_runs impl_1]
catch {
 if { $idrFlowPropertiesConstraints != {} } {
   set_param runs.disableIDRFlowPropertyConstraints $idrFlowPropertiesConstraints
 }
}

puts "INFO: Project created:${_xil_proj_name_}"
# Create 'drc_1' gadget (if not found)
if {[string equal [get_dashboard_gadgets  [ list "drc_1" ] ] ""]} {
create_dashboard_gadget -name {drc_1} -type drc
}
set obj [get_dashboard_gadgets [ list "drc_1" ] ]
set_property -name "reports" -value "impl_1#impl_1_route_report_drc_0" -objects $obj

# Create 'methodology_1' gadget (if not found)
if {[string equal [get_dashboard_gadgets  [ list "methodology_1" ] ] ""]} {
create_dashboard_gadget -name {methodology_1} -type methodology
}
set obj [get_dashboard_gadgets [ list "methodology_1" ] ]
set_property -name "reports" -value "impl_1#impl_1_route_report_methodology_0" -objects $obj

# Create 'power_1' gadget (if not found)
if {[string equal [get_dashboard_gadgets  [ list "power_1" ] ] ""]} {
create_dashboard_gadget -name {power_1} -type power
}
set obj [get_dashboard_gadgets [ list "power_1" ] ]
set_property -name "reports" -value "impl_1#impl_1_route_report_power_0" -objects $obj

# Create 'timing_1' gadget (if not found)
if {[string equal [get_dashboard_gadgets  [ list "timing_1" ] ] ""]} {
create_dashboard_gadget -name {timing_1} -type timing
}
set obj [get_dashboard_gadgets [ list "timing_1" ] ]
set_property -name "reports" -value "impl_1#impl_1_route_report_timing_summary_0" -objects $obj

# Create 'utilization_1' gadget (if not found)
if {[string equal [get_dashboard_gadgets  [ list "utilization_1" ] ] ""]} {
create_dashboard_gadget -name {utilization_1} -type utilization
}
set obj [get_dashboard_gadgets [ list "utilization_1" ] ]
set_property -name "reports" -value "synth_1#synth_1_synth_report_utilization_0" -objects $obj
set_property -name "run.step" -value "synth_design" -objects $obj
set_property -name "run.type" -value "synthesis" -objects $obj

# Create 'utilization_2' gadget (if not found)
if {[string equal [get_dashboard_gadgets  [ list "utilization_2" ] ] ""]} {
create_dashboard_gadget -name {utilization_2} -type utilization
}
set obj [get_dashboard_gadgets [ list "utilization_2" ] ]
set_property -name "reports" -value "impl_1#impl_1_place_report_utilization_0" -objects $obj

move_dashboard_gadget -name {utilization_1} -row 0 -col 0
move_dashboard_gadget -name {power_1} -row 1 -col 0
move_dashboard_gadget -name {drc_1} -row 2 -col 0
move_dashboard_gadget -name {timing_1} -row 0 -col 1
move_dashboard_gadget -name {utilization_2} -row 1 -col 1
move_dashboard_gadget -name {methodology_1} -row 2 -col 1
